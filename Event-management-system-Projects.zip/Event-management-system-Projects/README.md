# Event-management-system
The event management website is to help event organizers to plan and manage their clients’ events like wedding, musical concerts, corporate seminars, birthday etc. in an efficient manner. Hence, offering a wide range of event management services to people. The system can lead to error free, secure, reliable and fast management system. 
